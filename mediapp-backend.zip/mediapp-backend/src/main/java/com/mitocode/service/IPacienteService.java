package com.mitocode.service;

import com.mitocode.model.Paciente;

public interface IPacienteService extends ICRUD<Paciente, Integer>{
	
}
