package com.mitocode.repo;

import com.mitocode.model.Especialidad;

//@Repository
public interface IEspecialidadRepo extends IGenericRepo<Especialidad, Integer>{

}
