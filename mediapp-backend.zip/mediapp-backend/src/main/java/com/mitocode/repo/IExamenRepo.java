package com.mitocode.repo;

import com.mitocode.model.Examen;

//@Repository
public interface IExamenRepo extends IGenericRepo<Examen, Integer>{

}
