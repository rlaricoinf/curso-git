package com.mitocode.repo;

import com.mitocode.model.Paciente;

//@Repository
public interface IPacienteRepo extends IGenericRepo<Paciente, Integer>{

}
