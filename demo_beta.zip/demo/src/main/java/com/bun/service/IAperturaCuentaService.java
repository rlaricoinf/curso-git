package com.bun.service;

import com.bun.model.AperturaCuenta;

import java.util.List;

public interface IAperturaCuentaService extends ICRUD<AperturaCuenta, Long> {

    // si se requiere algun metodo diferente de 'registrar', 'modificar', 'listar', 'eliminar'
    // En esta interface podemos declarar los metodos personalizados para AperturaCuenta
}
