/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bun.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 *
 * @author rlarico
 */
@Data
@Entity
@Table(name = "APERTURA_CUENTA")
@NamedQueries({
        @NamedQuery(name = "AperturaCuenta.findAll", query = "SELECT a FROM AperturaCuenta a"),
        @NamedQuery(name = "AperturaCuenta.findByIdAperturaCuentaPk", query = "SELECT a FROM AperturaCuenta a WHERE a.idAperturaCuentaPk = :idAperturaCuentaPk")
})
public class AperturaCuenta implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="SQ_APERTURA_CUENTA", sequenceName="SQ_APERTURA_CUENTA",initialValue=1,allocationSize=1)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_APERTURA_CUENTA")
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID_APERTURA_CUENTA_PK")
    private Long idAperturaCuentaPk;
    @Column(name = "TIPO_PRODUCTO")
    private Integer tipoProducto;
    @Size(max = 100)
    @Column(name = "NUMERO_CUENTA")
    private String numeroCuenta;
    @Size(max = 15)
    @Column(name = "MONEDA")
    private String moneda;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "MONTO")
    private BigDecimal monto;
    @Column(name = "FECHA_CREACION")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaCreacion;
    @Column(name = "SUCURSAL")
    private Integer sucursal;
//    @Size(max = 20)
//    @Column(name = "REGISTER_USER")
//    private String registerUser;
//    @Column(name = "REGISTER_DATE")
//    @Temporal(TemporalType.TIMESTAMP)
//    private Date registerDate;
//    @Size(max = 20)
//    @Column(name = "LAST_MODIFY_USER")
//    private String lastModifyUser;
//    @Size(max = 20)
//    @Column(name = "LAST_MODIFY_IP")
//    private String lastModifyIp;
//    @Column(name = "LAST_MODIFY_DATE")
//    @Temporal(TemporalType.TIMESTAMP)
//    private Date lastModifyDate;
//    @Column(name = "LAST_MODIFY_APP")
//    private Long lastModifyApp;
    @JoinColumn(name = "ID_CLIENTE_FK", referencedColumnName = "ID_CLIENTE_PK")
    @ManyToOne(fetch = FetchType.LAZY)
    @JsonBackReference
    private Cliente idClienteFk;

    public AperturaCuenta() {
    }

    public AperturaCuenta(Long idAperturaCuentaPk) {
        this.idAperturaCuentaPk = idAperturaCuentaPk;
    }


}
