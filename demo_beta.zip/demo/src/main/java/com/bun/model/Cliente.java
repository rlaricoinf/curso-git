/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bun.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 * @author rlarico
 */
@Data
@Entity
@Table(name = "CLIENTE")
@NamedQueries({
        @NamedQuery(name = "Cliente.findAll", query = "SELECT c FROM Cliente c"),
        @NamedQuery(name = "Cliente.findByIdClientePk", query = "SELECT c FROM Cliente c WHERE c.idClientePk = :idClientePk"),
        @NamedQuery(name = "Cliente.findByNombre", query = "SELECT c FROM Cliente c WHERE c.nombre = :nombre"),
        @NamedQuery(name = "Cliente.findByPaterno", query = "SELECT c FROM Cliente c WHERE c.paterno = :paterno")
        })
public class Cliente implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="SQ_CLIENTE", sequenceName="SQ_CLIENTE",initialValue=1,allocationSize=1)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_CLIENTE")
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID_CLIENTE_PK")
    private Long idClientePk;
    @Size(max = 50)
    @Column(name = "NOMBRE")
    private String nombre;
    @Size(max = 50)
    @Column(name = "PATERNO")
    private String paterno;
    @Size(max = 50)
    @Column(name = "MATERNO")
    private String materno;
    @Size(max = 50)
    @Column(name = "TIPO_DOCUMENTO")
    private String tipoDocumento;
    @Size(max = 100)
    @Column(name = "DOCUMENTO_IDENTIDAD")
    private String documentoIdentidad;
    @Column(name = "FECHA_NACIMIENTO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaNacimiento;
    @Column(name = "GENERO")
    private String genero;
//    @Size(max = 20)
//    @Column(name = "REGISTER_USER")
//    private String registerUser;
//    @Column(name = "REGISTER_DATE")
//    @Temporal(TemporalType.TIMESTAMP)
//    private Date registerDate;
//    @Size(max = 20)
//    @Column(name = "LAST_MODIFY_USER")
//    private String lastModifyUser;
//    @Size(max = 20)
//    @Column(name = "LAST_MODIFY_IP")
//    private String lastModifyIp;
//    @Column(name = "LAST_MODIFY_DATE")
//    @Temporal(TemporalType.TIMESTAMP)
//    private Date lastModifyDate;
//    @Column(name = "LAST_MODIFY_APP")
//    private Long lastModifyApp;
    @OneToMany(mappedBy = "idClienteFk", fetch = FetchType.LAZY)
    @JsonManagedReference
    private List<AperturaCuenta> aperturaCuentaList;

    public Cliente() {
    }

    public Cliente(Long idClientePk) {
        this.idClientePk = idClientePk;
    }

}

