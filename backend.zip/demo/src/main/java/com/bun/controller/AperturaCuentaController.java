package com.bun.controller;

import com.bun.exception.ModelNotFoundException;
import com.bun.model.AperturaCuenta;
import com.bun.service.IAperturaCuentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/apertura-cuentas")
public class AperturaCuentaController {

    @Autowired
    private IAperturaCuentaService service;

    @GetMapping
    private ResponseEntity<List<AperturaCuenta>> listar() throws Exception {
        List<AperturaCuenta> lst = service.listar();
        return ResponseEntity.ok(lst);
    }

    @GetMapping("/{id}")
    private ResponseEntity<AperturaCuenta> listarPorId(@PathVariable("id") Long id) throws Exception {
        AperturaCuenta aperturaCuenta = service.listarPorId(id);
        if(aperturaCuenta == null){
            throw new ModelNotFoundException("ID NO ENCONTRADO "+id);
        }
        return ResponseEntity.ok(aperturaCuenta);
    }

    @PostMapping
    private ResponseEntity<AperturaCuenta> registrar(@RequestBody AperturaCuenta c) throws Exception {
        AperturaCuenta aperturaCuenta = service.registrar(c);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(aperturaCuenta.getIdAperturaCuentaPk()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping
    private ResponseEntity<AperturaCuenta> modificar(@RequestBody AperturaCuenta c) throws Exception {
        AperturaCuenta aperturaCuenta = service.modificar(c);
        return new ResponseEntity<AperturaCuenta>(aperturaCuenta, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    private ResponseEntity<Void> eliminar(@PathVariable("id") Long id) throws Exception {
        service.eliminar(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
}
