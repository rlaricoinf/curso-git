package com.bun.controller;

import com.bun.exception.ModelNotFoundException;
import com.bun.model.Cliente;
import com.bun.service.IClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/clientes")
public class ClienteController {

    @Autowired
    private IClienteService service;

    @GetMapping
    private ResponseEntity<List<Cliente>> listar() throws Exception {
        List<Cliente> lst = service.listar();
        return ResponseEntity.ok(lst);
    }

    @GetMapping("/{id}")
    private ResponseEntity<Cliente> listarPorId(@PathVariable("id") Long id) throws Exception {
        Cliente cliente = service.listarPorId(id);
        if(cliente == null){
            throw new ModelNotFoundException("ID NO ENCONTRADO "+id);
        }
        return ResponseEntity.ok(cliente);
    }

    @PostMapping
    private ResponseEntity<Cliente> registrar(@RequestBody Cliente c) throws Exception {
        Cliente cliente = service.registrar(c);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(cliente.getIdClientePk()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping
    private ResponseEntity<Cliente> modificar(@RequestBody Cliente c) throws Exception {
        Cliente cliente = service.modificar(c);
        return new ResponseEntity<Cliente>(cliente, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    private ResponseEntity<Void> eliminar(@PathVariable("id") Long id) throws Exception {
        service.eliminar(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
}
