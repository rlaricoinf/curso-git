package com.bun.service.impl;

import com.bun.model.AperturaCuenta;
import com.bun.repo.IAperturaCuentaRepo;
import com.bun.repo.IGenericRepo;
import com.bun.service.IAperturaCuentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AperturaCuentaServiceImpl extends ICRUDImpl<AperturaCuenta, Long> implements IAperturaCuentaService {

    @Autowired
    IAperturaCuentaRepo repo;

    @Override
    protected IGenericRepo<AperturaCuenta, Long> getRepo() {
        return repo;
    }
}
