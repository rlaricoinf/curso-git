package com.bun.service.impl;

import com.bun.model.Cliente;
import com.bun.repo.IClienteRepo;
import com.bun.repo.IGenericRepo;
import com.bun.service.IClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClienteServiceImpl extends ICRUDImpl<Cliente, Long> implements IClienteService {

    @Autowired
    IClienteRepo repo;

    @Override
    protected IGenericRepo<Cliente, Long> getRepo() {
        return repo;
    }
}
