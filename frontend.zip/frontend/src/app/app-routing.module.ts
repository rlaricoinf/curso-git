import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClientesComponent } from './clientes/clientes.component';
import { AperturaCuentaComponent } from './apertura-cuenta/apertura-cuenta.component';

const routes: Routes = [
  { path: 'clientes', component: ClientesComponent },
  { path: 'apertura-cuenta', component: AperturaCuentaComponent },
  { path: '', redirectTo: '/clientes', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
