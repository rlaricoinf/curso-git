import { Component, OnInit } from '@angular/core';
import { ClientesService } from '../servicios/clientes.service';
import { Cliente } from '../models/cliente.model';

import { MatTableDataSource } from '@angular/material/table';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { AperturaCuenta } from '../models/apertura-cuenta.model';

@Component({
  selector: 'app-clientes',
  templateUrl: './clientes.component.html',
  styleUrls: ['./clientes.component.css']
})
export class ClientesComponent implements OnInit {
  clientes: Cliente[] = [];
  clienteForm: FormGroup;
  displayedColumns: string[] = ['id', 'nombre', 'paterno',
      'materno','tipoDocumento','documentoIdentidad',
      'fechaNacimiento','genero','acciones'];

  tiposDocuemntos: string[] = ['CI','NIT','DNI'];
  selectedTipoDocumento: string='';

  tiposGeneros: string[] = ['M','F','-'];
  selectedTipoGenero: string='';


  cuentasCliente: AperturaCuenta[] = [];

  constructor(
    private fb: FormBuilder,
    private clientesService: ClientesService) {
      this.clienteForm = this.fb.group({
        idClientePk: [null],
        nombre: [''],
        paterno: [''],
        materno: [''],
        tipoDocumento: [''],
        documentoIdentidad: [''],
        fechaNacimiento:[null],
        genero: [''],
        cuentas: [null]
      });

      //this.selectedTipoDocumento = this.tiposDocuemntos[0];
     //this.selectedTipoGenero = this.tiposGeneros[0];
    }

  ngOnInit(): void {
    this.loadClientes();
  }



  loadClientes(): void {
    this.clientesService.getClientes().subscribe(data => {
      this.clientes = data;
    });

    this.selectedTipoDocumento='';
    this.selectedTipoGenero = '';
  }

  submit(): void {

    // antes de guardar
    this.clienteForm.patchValue({
      tipoDocumento: this.selectedTipoDocumento,
      genero:this.selectedTipoGenero
      //tipoDocumento: 'Pruebaaa'
    });

    if (this.clienteForm.value.id) {
      this.clientesService.updateCliente(this.clienteForm.value).subscribe(() => {
        this.loadClientes();
        this.clienteForm.reset();
      });
    } else {
      this.clientesService.addCliente(this.clienteForm.value).subscribe(() => {
        this.loadClientes();
        this.clienteForm.reset();
      });
    }
  }

  edit(cliente: Cliente): void {
    this.clienteForm.setValue(cliente);
  }

  delete(id: number): void {
    this.clientesService.deleteCliente(id).subscribe(() => {
      this.loadClientes();
    });
  }


  removerCuenta(index: number) {
    this.cuentasCliente.splice(index, 1);
  }
}
