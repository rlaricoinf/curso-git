import { AperturaCuenta } from './apertura-cuenta.model';

export interface Cliente {
  idClientePk: number;
  nombre: string;
  paterno: string;
  materno: string;
  tipoDocumento: string;
  documentoIdentidad: string;
  fechaNacimiento: string; //2020-02-13T11:30:05 ISODate || moment.js
  genero: string;
  cuentas: AperturaCuenta[];
}
