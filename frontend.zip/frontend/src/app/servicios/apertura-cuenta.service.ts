import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AperturaCuenta } from '../models/apertura-cuenta.model';

@Injectable({
  providedIn: 'root'
})
export class AperturaCuentaService {

  private apiUrl = 'http://localhost:8077/apertura-cuentas';

  constructor(private http: HttpClient) { }

  getCuentas(): Observable<AperturaCuenta[]> {
    return this.http.get<AperturaCuenta[]>(this.apiUrl);
  }

  getCuenta(id: number): Observable<AperturaCuenta> {
    return this.http.get<AperturaCuenta>(`${this.apiUrl}/${id}`);
  }

  addCuenta(cuenta: AperturaCuenta): Observable<AperturaCuenta> {
    return this.http.post<AperturaCuenta>(this.apiUrl, cuenta);
  }

  updateCuenta(cuenta: AperturaCuenta): Observable<AperturaCuenta> {
    return this.http.put<AperturaCuenta>(`${this.apiUrl}/${cuenta.idAperturaCuentaPk}`, cuenta);
  }

  deleteCuenta(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
