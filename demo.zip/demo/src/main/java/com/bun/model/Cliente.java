/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bun.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 * @author rlarico
 */
@Entity
@Table(name = "CLIENTE")
@NamedQueries({
        @NamedQuery(name = "Cliente.findAll", query = "SELECT c FROM Cliente c"),
        @NamedQuery(name = "Cliente.findByIdClientePk", query = "SELECT c FROM Cliente c WHERE c.idClientePk = :idClientePk"),
        @NamedQuery(name = "Cliente.findByNombre", query = "SELECT c FROM Cliente c WHERE c.nombre = :nombre"),
        @NamedQuery(name = "Cliente.findByPaterno", query = "SELECT c FROM Cliente c WHERE c.paterno = :paterno"),
        @NamedQuery(name = "Cliente.findByMaterno", query = "SELECT c FROM Cliente c WHERE c.materno = :materno"),
        @NamedQuery(name = "Cliente.findByTipoDocumento", query = "SELECT c FROM Cliente c WHERE c.tipoDocumento = :tipoDocumento"),
        @NamedQuery(name = "Cliente.findByDocumentoIdentidad", query = "SELECT c FROM Cliente c WHERE c.documentoIdentidad = :documentoIdentidad"),
        @NamedQuery(name = "Cliente.findByFechaNacimiento", query = "SELECT c FROM Cliente c WHERE c.fechaNacimiento = :fechaNacimiento"),
        @NamedQuery(name = "Cliente.findByGenero", query = "SELECT c FROM Cliente c WHERE c.genero = :genero"),
        @NamedQuery(name = "Cliente.findByRegisterUser", query = "SELECT c FROM Cliente c WHERE c.registerUser = :registerUser"),
        @NamedQuery(name = "Cliente.findByRegisterDate", query = "SELECT c FROM Cliente c WHERE c.registerDate = :registerDate"),
        @NamedQuery(name = "Cliente.findByLastModifyUser", query = "SELECT c FROM Cliente c WHERE c.lastModifyUser = :lastModifyUser"),
        @NamedQuery(name = "Cliente.findByLastModifyIp", query = "SELECT c FROM Cliente c WHERE c.lastModifyIp = :lastModifyIp"),
        @NamedQuery(name = "Cliente.findByLastModifyDate", query = "SELECT c FROM Cliente c WHERE c.lastModifyDate = :lastModifyDate"),
        @NamedQuery(name = "Cliente.findByLastModifyApp", query = "SELECT c FROM Cliente c WHERE c.lastModifyApp = :lastModifyApp")})
public class Cliente implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="SQ_CLIENTE", sequenceName="SQ_CLIENTE",initialValue=1,allocationSize=1)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_CLIENTE")
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID_CLIENTE_PK")
    private Long idClientePk;
    @Size(max = 50)
    @Column(name = "NOMBRE")
    private String nombre;
    @Size(max = 50)
    @Column(name = "PATERNO")
    private String paterno;
    @Size(max = 50)
    @Column(name = "MATERNO")
    private String materno;
    @Size(max = 50)
    @Column(name = "TIPO_DOCUMENTO")
    private String tipoDocumento;
    @Size(max = 100)
    @Column(name = "DOCUMENTO_IDENTIDAD")
    private String documentoIdentidad;
    @Column(name = "FECHA_NACIMIENTO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaNacimiento;
    @Column(name = "GENERO")
    private String genero;
    @Size(max = 20)
    @Column(name = "REGISTER_USER")
    private String registerUser;
    @Column(name = "REGISTER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date registerDate;
    @Size(max = 20)
    @Column(name = "LAST_MODIFY_USER")
    private String lastModifyUser;
    @Size(max = 20)
    @Column(name = "LAST_MODIFY_IP")
    private String lastModifyIp;
    @Column(name = "LAST_MODIFY_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifyDate;
    @Column(name = "LAST_MODIFY_APP")
    private Long lastModifyApp;
    @OneToMany(mappedBy = "idClienteFk", fetch = FetchType.LAZY)
    private List<AperturaCuenta> aperturaCuentaList;

    public Cliente() {
    }

    public Cliente(Long idClientePk) {
        this.idClientePk = idClientePk;
    }

    public Long getIdClientePk() {
        return idClientePk;
    }

    public void setIdClientePk(Long idClientePk) {
        this.idClientePk = idClientePk;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPaterno() {
        return paterno;
    }

    public void setPaterno(String paterno) {
        this.paterno = paterno;
    }

    public String getMaterno() {
        return materno;
    }

    public void setMaterno(String materno) {
        this.materno = materno;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getDocumentoIdentidad() {
        return documentoIdentidad;
    }

    public void setDocumentoIdentidad(String documentoIdentidad) {
        this.documentoIdentidad = documentoIdentidad;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getRegisterUser() {
        return registerUser;
    }

    public void setRegisterUser(String registerUser) {
        this.registerUser = registerUser;
    }

    public Date getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(Date registerDate) {
        this.registerDate = registerDate;
    }

    public String getLastModifyUser() {
        return lastModifyUser;
    }

    public void setLastModifyUser(String lastModifyUser) {
        this.lastModifyUser = lastModifyUser;
    }

    public String getLastModifyIp() {
        return lastModifyIp;
    }

    public void setLastModifyIp(String lastModifyIp) {
        this.lastModifyIp = lastModifyIp;
    }

    public Date getLastModifyDate() {
        return lastModifyDate;
    }

    public void setLastModifyDate(Date lastModifyDate) {
        this.lastModifyDate = lastModifyDate;
    }

    public Long getLastModifyApp() {
        return lastModifyApp;
    }

    public void setLastModifyApp(Long lastModifyApp) {
        this.lastModifyApp = lastModifyApp;
    }

    public List<AperturaCuenta> getAperturaCuentaList() {
        return aperturaCuentaList;
    }

    public void setAperturaCuentaList(List<AperturaCuenta> aperturaCuentaList) {
        this.aperturaCuentaList = aperturaCuentaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idClientePk != null ? idClientePk.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cliente)) {
            return false;
        }
        Cliente other = (Cliente) object;
        if ((this.idClientePk == null && other.idClientePk != null) || (this.idClientePk != null && !this.idClientePk.equals(other.idClientePk))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.bun.model.Cliente[ idClientePk=" + idClientePk + " ]";
    }

}

