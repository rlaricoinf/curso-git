/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bun.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 *
 * @author rlarico
 */
@Entity
@Table(name = "APERTURA_CUENTA")
@NamedQueries({
        @NamedQuery(name = "AperturaCuenta.findAll", query = "SELECT a FROM AperturaCuenta a"),
        @NamedQuery(name = "AperturaCuenta.findByIdAperturaCuentaPk", query = "SELECT a FROM AperturaCuenta a WHERE a.idAperturaCuentaPk = :idAperturaCuentaPk"),
        @NamedQuery(name = "AperturaCuenta.findByTipoProducto", query = "SELECT a FROM AperturaCuenta a WHERE a.tipoProducto = :tipoProducto"),
        @NamedQuery(name = "AperturaCuenta.findByNumeroCuenta", query = "SELECT a FROM AperturaCuenta a WHERE a.numeroCuenta = :numeroCuenta"),
        @NamedQuery(name = "AperturaCuenta.findByMoneda", query = "SELECT a FROM AperturaCuenta a WHERE a.moneda = :moneda"),
        @NamedQuery(name = "AperturaCuenta.findByMonto", query = "SELECT a FROM AperturaCuenta a WHERE a.monto = :monto"),
        @NamedQuery(name = "AperturaCuenta.findByFechaCreacion", query = "SELECT a FROM AperturaCuenta a WHERE a.fechaCreacion = :fechaCreacion"),
        @NamedQuery(name = "AperturaCuenta.findBySucursal", query = "SELECT a FROM AperturaCuenta a WHERE a.sucursal = :sucursal"),
        @NamedQuery(name = "AperturaCuenta.findByRegisterUser", query = "SELECT a FROM AperturaCuenta a WHERE a.registerUser = :registerUser"),
        @NamedQuery(name = "AperturaCuenta.findByRegisterDate", query = "SELECT a FROM AperturaCuenta a WHERE a.registerDate = :registerDate"),
        @NamedQuery(name = "AperturaCuenta.findByLastModifyUser", query = "SELECT a FROM AperturaCuenta a WHERE a.lastModifyUser = :lastModifyUser"),
        @NamedQuery(name = "AperturaCuenta.findByLastModifyIp", query = "SELECT a FROM AperturaCuenta a WHERE a.lastModifyIp = :lastModifyIp"),
        @NamedQuery(name = "AperturaCuenta.findByLastModifyDate", query = "SELECT a FROM AperturaCuenta a WHERE a.lastModifyDate = :lastModifyDate"),
        @NamedQuery(name = "AperturaCuenta.findByLastModifyApp", query = "SELECT a FROM AperturaCuenta a WHERE a.lastModifyApp = :lastModifyApp")})
public class AperturaCuenta implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="SQ_APERTURA_CUENTA", sequenceName="SQ_APERTURA_CUENTA",initialValue=1,allocationSize=1)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_APERTURA_CUENTA")
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID_APERTURA_CUENTA_PK")
    private Long idAperturaCuentaPk;
    @Column(name = "TIPO_PRODUCTO")
    private Integer tipoProducto;
    @Size(max = 100)
    @Column(name = "NUMERO_CUENTA")
    private String numeroCuenta;
    @Size(max = 15)
    @Column(name = "MONEDA")
    private String moneda;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "MONTO")
    private BigDecimal monto;
    @Column(name = "FECHA_CREACION")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaCreacion;
    @Column(name = "SUCURSAL")
    private Integer sucursal;
    @Size(max = 20)
    @Column(name = "REGISTER_USER")
    private String registerUser;
    @Column(name = "REGISTER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date registerDate;
    @Size(max = 20)
    @Column(name = "LAST_MODIFY_USER")
    private String lastModifyUser;
    @Size(max = 20)
    @Column(name = "LAST_MODIFY_IP")
    private String lastModifyIp;
    @Column(name = "LAST_MODIFY_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifyDate;
    @Column(name = "LAST_MODIFY_APP")
    private Long lastModifyApp;
    @JoinColumn(name = "ID_CLIENTE_FK", referencedColumnName = "ID_CLIENTE_PK")
    @ManyToOne(fetch = FetchType.LAZY)
    private Cliente idClienteFk;

    public AperturaCuenta() {
    }

    public AperturaCuenta(Long idAperturaCuentaPk) {
        this.idAperturaCuentaPk = idAperturaCuentaPk;
    }

    public Long getIdAperturaCuentaPk() {
        return idAperturaCuentaPk;
    }

    public void setIdAperturaCuentaPk(Long idAperturaCuentaPk) {
        this.idAperturaCuentaPk = idAperturaCuentaPk;
    }

    public Integer getTipoProducto() {
        return tipoProducto;
    }

    public void setTipoProducto(Integer tipoProducto) {
        this.tipoProducto = tipoProducto;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public BigDecimal getMonto() {
        return monto;
    }

    public void setMonto(BigDecimal monto) {
        this.monto = monto;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Integer getSucursal() {
        return sucursal;
    }

    public void setSucursal(Integer sucursal) {
        this.sucursal = sucursal;
    }

    public String getRegisterUser() {
        return registerUser;
    }

    public void setRegisterUser(String registerUser) {
        this.registerUser = registerUser;
    }

    public Date getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(Date registerDate) {
        this.registerDate = registerDate;
    }

    public String getLastModifyUser() {
        return lastModifyUser;
    }

    public void setLastModifyUser(String lastModifyUser) {
        this.lastModifyUser = lastModifyUser;
    }

    public String getLastModifyIp() {
        return lastModifyIp;
    }

    public void setLastModifyIp(String lastModifyIp) {
        this.lastModifyIp = lastModifyIp;
    }

    public Date getLastModifyDate() {
        return lastModifyDate;
    }

    public void setLastModifyDate(Date lastModifyDate) {
        this.lastModifyDate = lastModifyDate;
    }

    public Long getLastModifyApp() {
        return lastModifyApp;
    }

    public void setLastModifyApp(Long lastModifyApp) {
        this.lastModifyApp = lastModifyApp;
    }

    public Cliente getIdClienteFk() {
        return idClienteFk;
    }

    public void setIdClienteFk(Cliente idClienteFk) {
        this.idClienteFk = idClienteFk;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAperturaCuentaPk != null ? idAperturaCuentaPk.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AperturaCuenta)) {
            return false;
        }
        AperturaCuenta other = (AperturaCuenta) object;
        if ((this.idAperturaCuentaPk == null && other.idAperturaCuentaPk != null) || (this.idAperturaCuentaPk != null && !this.idAperturaCuentaPk.equals(other.idAperturaCuentaPk))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.bun.model.AperturaCuenta[ idAperturaCuentaPk=" + idAperturaCuentaPk + " ]";
    }

}
