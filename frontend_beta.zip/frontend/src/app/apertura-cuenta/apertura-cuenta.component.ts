import { Component } from '@angular/core';
import { AperturaCuenta } from '../models/apertura-cuenta.model';
import { AperturaCuentaService } from '../servicios/apertura-cuenta.service';

@Component({
  selector: 'app-apertura-cuenta',
  templateUrl: './apertura-cuenta.component.html',
  styleUrls: ['./apertura-cuenta.component.css']
})
export class AperturaCuentaComponent {

  cuentas: AperturaCuenta[] = [];

  constructor(private aperturaCuentaService: AperturaCuentaService) { }

  ngOnInit(): void {
    this.aperturaCuentaService.getCuentas().subscribe(data => {
      this.cuentas = data;
    });
  }
}
