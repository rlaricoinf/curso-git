
import { Cliente } from './cliente.model';

export interface AperturaCuenta {
  idAperturaCuentaPk: number;
  cliente: Cliente;
  tipoProducto: string;
  numeroCuenta: string;
  moneda: string;
  monto: number;
  fechaCreacion: string; //2020-02-13T11:30:05 ISODate || moment.js
  sucursal: string;
}
